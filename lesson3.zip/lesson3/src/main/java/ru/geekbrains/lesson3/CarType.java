package ru.geekbrains.lesson3;

public enum CarType {
    Sedan,
    Hatchback,
    Pickup,
    Sport
}