package ru.geekbrains.lesson3;

/**
 * Заправочная станция
 */
public interface Refueling {

    /**
     * Заправка
     */
    void fuel(FuelType fuelType);

}
