package ru.geekbrains.lesson3;

public interface Wiping {

    void wipMirrors();
    void wipWindshield();
    void wipHeadlights();

}
