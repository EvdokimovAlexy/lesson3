package ru.geekbrains.lesson3;

public enum FuelType {
    Diesel,
    Gasoline
}
