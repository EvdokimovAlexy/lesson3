package ru.geekbrains.lesson3.ocp;

public interface Shape {

    /**
     * Вернуть площадь фигуры
     * @return площадь фигуры
     */
    double getArea();

}
