package ru.geekbrains.lesson3;

/**
 * Тип коробки передач
 */
public enum GearboxType {
    AT, // Automatic transmission
    MT  // Manual transmission
}
