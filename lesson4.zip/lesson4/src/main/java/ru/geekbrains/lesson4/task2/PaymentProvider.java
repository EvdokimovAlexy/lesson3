package ru.geekbrains.lesson4.task2;

public class PaymentProvider {

    public boolean buyTicket(int orderId, String cardNo, double amount){
        // Посылаем запрос на формирование заявки на проведение платежа в процессинговую компанию (ProcessingCompany)
        return true;
    }
}
