package ru.geekbrains.lesson5;

/**
 * Сущность
 */
public interface Entity {

    int getId();

}
